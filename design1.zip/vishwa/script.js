function menu_open() {
    const menuDiv = document.getElementById("menu_drawer");
    menuDiv.classList.remove("hidden");
  }
  
  function menu_close() {
    const menuDiv = document.getElementById("menu_drawer");
    menuDiv.classList.add("hidden");
  }

  // search bar
const searchDiv = document.getElementById("search_bar");
function search_Open(){
 
  searchDiv.classList.remove("hidden");
 
}

function search_close(){
  searchDiv.classList.add("hidden");
}

// side nav
const sideNav =document.getElementById("side_nav")
function side_navOpen(){
    sideNav.classList.remove("hidden")
}

function side_close(){
    sideNav.classList.add("hidden")
} 



function openpopup() {
  document.getElementById('popupWindow').classList.remove('hidden');
}

function closePopup() {
  document.getElementById('popupWindow').classList.add('hidden');
}

function resumeoption() {
 
  document.getElementById('options').classList.remove('hidden');
  
}