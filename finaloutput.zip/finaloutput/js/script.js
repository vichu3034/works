// menu icons toggle

const menu_dot = document.getElementById("menu_dot");
const menu_xmark = document.getElementById("menu_xmark");


function menu_iconToggle() {
    // Toggle the visibility of the menu items
    const menu_items =document.getElementById("menu_items");
    menu_items.classList.toggle("hidden");
    

  // Toggle the visibility of the menu icons
  menu_dot.classList.toggle("hidden");
  menu_xmark.classList.toggle("hidden");
  menu_xmark.classList.toggle("z-10");
}




// Function to open the pop-up
function openPopup() {
  document.getElementById("popupWindow").classList.remove("hidden");
}

// Function to close the pop-up
function closePopup() {
  document.getElementById("popupWindow").classList.add("hidden");
}

// Add event listener to the entire div
document.getElementById("add-resume").addEventListener("click", openPopup);





  // Function to open the pop-up

  // Function to open the pop-up
  function openEditDeletePopup() {
    document.getElementById("popupEditDelete").classList.remove("hidden");
  }

  // Function to close the pop-up (optional, if needed)
  function closeEditDeletePopup() {
    document.getElementById("popupEditDelete").classList.add("hidden");
  }

  // Add event listener to the icon
  document.getElementById("triggerPopup").addEventListener("click", openEditDeletePopup);




  // mobview resume popup

  function openMobilePopup() {
    document.getElementById("mobpopup").classList.remove("hidden");
}

function closeMobilePopup() {
    document.getElementById("mobpopup").classList.add("hidden");
}